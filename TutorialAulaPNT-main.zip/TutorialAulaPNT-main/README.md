# TutorialAulaPNT
Execução do tutorial para atividade de PNT usando banco mongodb + EJS + javaScript + Node
para executar precisa dar o comando no terminal e dentro da raiz do projeot os comandos abaixo:
$ npm install 
e depois 
$ npm run dev
